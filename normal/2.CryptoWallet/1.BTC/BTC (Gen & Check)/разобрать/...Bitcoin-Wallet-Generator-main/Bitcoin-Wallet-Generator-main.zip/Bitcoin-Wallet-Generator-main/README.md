# Bitcoin-Wallet-Generator
An Bitcoin wallet (Private Key, Public Key &amp; Bitcoin Address ) generator from a number, with python. It also checks Wallets with Positive balance.

# Donations: 3Eb1YxpmAPFc3E8QWAgMb3oxjxVenbH6fj

# How it Works
 It takes an integer as an argument and convert it into a compressed private key then into a public key and then public key to a BitCoin adress, all those generated wallets are saved in a file `wallet.txt` and It use `BlockCypher & MoneyWagon` to check if there is an postive balance, if any wallet has a positive balance then it saved in another file called `wallet_with_money.txt`.

# Usage
  
## Linux
  `python3 wallet_generator.py or use any python command which is compatible with your system`
  
## Windows
  `python3 wallet_generator.py or use any python command which is compatible with your system`
  
## Mac
  `python3 wallet_generator.py or use any python command which is compatible with your system`
  

 ## contacts
 ``` 
 Email : contact@yehanwasura.ml \ yehantest@gmail.com
 Instagram : https://instagram.com/official.yehanwasura.lk
 Discord : P4N70M#0651 
 
 ```
   
# Donations
``` 
Bitcoin : 3Eb1YxpmAPFc3E8QWAgMb3oxjxVenbH6fj
Paypal : paypal.me/cyberrex599
Patreon : patreon.com/yehanwasura 

```
 
