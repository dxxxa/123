# Auto keys.lol program!
The program automatically searches the keys.lol site for any active wallets and logs them in a file! Multiply the pages read by 128 and you get the amount of bitcoin addresses searched. If you get a large group of computers together and run this program you would eventually stumble upon a private key that you could use.

# Installation
Download the Python 3.7 installer and run it. Select custom installation and make sure the add to PATH box is checked. All the components should be installed with python. run ```pip install requests_html``` to intstall the components

# Usage
Running the CMD_1.4-BTC.py or CMD_1.4-ETH.py program will open a cmd window that will automatically search for keys and log the page address in a file. Enjoy!

# VERSION 1.4 release notes
Removed multi-threading but replaced the algorithm with a faster one
