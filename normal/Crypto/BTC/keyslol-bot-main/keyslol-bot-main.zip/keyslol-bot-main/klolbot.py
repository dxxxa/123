from src.BitcoinDriver import *

bp = BitcoinParser()
# print(bp.requests)
bp.run()