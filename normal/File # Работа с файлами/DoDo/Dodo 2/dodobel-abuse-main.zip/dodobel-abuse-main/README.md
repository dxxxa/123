# dodobel-abuse

### Получение инфорации о выбранной пиццерии Додо (Республика Беларусь)

 ## Установка и запуск на Linux
1. Устанавливаем git и python:

       apt-get update && apt-get -y install git python3 python3-{dev,pip}

2. Клонируем репозиторий и устанавливаем зависимости:
	
       git clone https://github.com/li0ard/dodobel-abuse && cd dodobel-abuse && pip3 install -r requirements.txt
      
3. Запускаем программу:

       python3 start.py

![](https://komarev.com/ghpvc/?username=dodobel-abuse&color=blue&label=Просмотров)

### Примечание

Идея была взята из: [@fuad00/dodopizza-abuse](https://github.com/fuad00/dodopizza-abuse)