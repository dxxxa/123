# dodopizza-abuse

### Получение инфорации о выбранной пиццерии Додо

![vid](https://user-images.githubusercontent.com/26776550/120511162-cf18f580-c3d2-11eb-82e1-2b0b990e4acb.gif)

 ## Установка и запуск на Linux
1. Устанавливаем git и python:

       apt-get update && apt-get -y install git python3 python3-pip

2. Клонируем репозиторий и устанавливаем зависимости:
	
       git clone https://github.com/fuad00/dodopizza-abuse && cd dodopizza-abuse && pip3 install -r requirements.txt
      
3. Запускаем программу:

       python3 start.py
	
## Примечание

### Ну да, нагавнокодил малёха, и что с того? 

1. Протестировано на:
   - Debian 10 [x64]
   - Windows 10 [x64]
 
2. Идеи/предложения приветствуются





![](https://komarev.com/ghpvc/?username=dodopizza-abuse&color=blue&label=Просмотров)
