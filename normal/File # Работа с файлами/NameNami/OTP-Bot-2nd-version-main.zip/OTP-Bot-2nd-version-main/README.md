# OTP-Bot-2nd-version
Why not\
Kinda lazy to write anything\
how to run?\
u can figure it urself its been a few months since i abondoned this one
btw its better no slash commands and such things.
