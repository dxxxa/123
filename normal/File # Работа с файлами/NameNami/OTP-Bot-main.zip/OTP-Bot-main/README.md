### Making New One but in .exe (not discord bot), A lot of New Features, Nice UI & For Free ofc (in few days)

### Note
- If you have any problem u can contact me
- Not for sell only  for personal use...You can remake it
- Only for Base/Example and then make your own otp bot
- Only work for Twilio
- Need Verified Twilio Acc to work
- Planning to make OTP Bot for Vonage
- https://cracked.io/NamiWoiiii
- https://patched.to/User/nami
- https://discord.gg/dm96sgkafP

## Installation

Requirements.

```bash
pip install Flask
pip install twilio
pip3 install discord
pip install -U discord-py-slash-command
```

## Setup

1.Download ngrok (you can watch youtube)\
\
2.make ngrok tunnel with ngrok http 5000 or ngrok http 127.0.0.1:5000\
\
3.fill the config.txt(run bot.py to get the config.txt)\
\
4.run voice_response.py (you can edit the script)\
\
5.Give enough permission to the bot\
\
6.run bot.py\
\
7.go into discord and use /call

![](https://i.imgur.com/5FoweFz.jpg)

### Twilio Note
- You can change the voice in https://console.twilio.com/us1/develop/voice/settings/text-to-speech

### Discord Bot Note
- Call
    - Digits
          - OTP Code Digits Amount

    - Phone Number
          - Target's Phone Number

   - Name
         - Target's Name

   - Company Name
         - Company's Name

- Call Again
   - If the call failed

### Donate
- LTC
   - LSwXv1XA3ozJW3rNnGZ9RzVqFsv3GHzPCi
- BTC
   - bc1qrmsa6uew8r7h7t37jrwss4wrh54chxqsc7hss6

### Error
- 50001 Missing Access
    - Give the Bot Enough Access
    - Make sure  the server id is correct
    - Make Sure the Oauth2  Url Gen Have the same scope as the pic above 
