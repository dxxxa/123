VERSION = (3, 5, 0)

__version__ = '.'.join(map(str, VERSION))
