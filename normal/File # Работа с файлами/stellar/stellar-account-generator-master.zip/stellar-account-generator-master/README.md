# stellar-account-generator
This is automatic script for creating account in Stellar network
